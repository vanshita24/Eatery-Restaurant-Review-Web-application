var express= require("express");
var router=express.Router();
var Restaurant=require("../models/restaurant");

//INDEX ROUTE-- to display all the campgrounds
router.get("/",function(req,res){
	//get all restaurants from DB
	Restaurant.find({},function(err, allrestaurants){
		if(err){
			console.log(err);
		}
		else{
			res.render("restaurants/index",{restaurants:allrestaurants,currentUser:req.user});
		}
	})
	
	
});
//app.get is used to display the restaurants and app.post is used to add a new restaurant

// CREATE ROUTE- add new restaurant to DB
router.post("/",isLoggedIn,function(req,res){
	//get data from form and add to the restaurants page
	var name=req.body.name;
	var image=req.body.image;
	var desc=req.body.description;
	var author={
		id:req.user._id,
		username:req.user.username
	};
	var newRestaurant={name:name,image:image,description:desc,author:author}
	//create a new restaurant and save to db
	Restaurant.create(newRestaurant,function(err,newlyCreated){
		if(err){
			console.log(err);
		}
		else{
			//redirect back to restaurants page
			res.redirect("/restaurants");
		}
	});
});
//NEW:show form to create a new restaurant
router.get("/new",isLoggedIn,function(req,res){
	res.render("restaurants/new.ejs");
});

//SHOW -- shows more info about one restaurant
router.get("/:id",function(req,res){
	//find the restaurant with provided id
	Restaurant.findById(req.params.id).populate("comments").exec(function(err,foundRestaurant){
		if(err){
			console.log(err);
		}
		else{
			//render show template with that restaurant
	res.render("restaurants/show",{restaurant: foundRestaurant});
		}
	});
	
});


//edit restaurant route
router.get("/:id/edit",checkRestaurantOwnership,function(req,res){
	Restaurant.findById(req.params.id,function(err,foundRestaurant){
		res.render("restaurants/edit",{restaurant:foundRestaurant});
	});
});
//update restaurant route
router.put("/:id",checkRestaurantOwnership,function(req,res){
	//find and update the correct campground
	Restaurant.findByIdAndUpdate(req.params.id,req.body.restaurant,function(err,updatedRestaurant){
		if(err){
			res.redirect("/restaurants");
			console.log(err);
		}else{
			//redirect to show page
			res.redirect("/restaurants/"+req.params.id);
		}
	});
	
});
//DESTROY RESTAURANT ROUTE
router.delete("/:id",checkRestaurantOwnership,function(req,res){
	Restaurant.findByIdAndRemove(req.params.id,function(err){
		if(err){
			res.redirect("/restaurants");
		}else{
			res.redirect("/restaurants");
		}
	});
});

function isLoggedIn(req,res,next){
	if(req.isAuthenticated()){
		return next();
	}
	res.redirect("/login")
}

function checkRestaurantOwnership(req,res,next){
	if(req.isAuthenticated()){
		Restaurant.findById(req.params.id,function(err,foundRestaurant){
			if(err){
				res.redirect("back");
			} else{
				//does the user own the campground?
				//console.log(foundCampground.author.id);//mongoose object
				//console.log(req.user._id);//string
				if(foundRestaurant.author.id.equals(req.user._id)){
					next();
					
				}else{
					res.redirect("back");
				}
				
		}
	});
	}
	else{
		res.redirect("back");
	}
}	




module.exports=router;
